package com.kkp.nure.animalrescue.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum PayoutStatus {
    NOT_REQUESTED(0, "Not requested"),
    REQUESTED(1, "Requested"),
    PENDING(2, "Pending"),
    COMPLETED(3, "Completed");

    public final int value;
    public final String strName;

    PayoutStatus(int value, String name) {
        this.value = value;
        this.strName = name;
    }

    @JsonValue
    public int toValue() {
        return value;
    }

    @JsonCreator
    public static PayoutStatus fromValue(int value) {
        if(value == NOT_REQUESTED.value)
            return NOT_REQUESTED;
        if(value == REQUESTED.value)
            return REQUESTED;
        if(value == PENDING.value)
            return PENDING;
        if(value == COMPLETED.value)
            return COMPLETED;

        return null;
    }
}
